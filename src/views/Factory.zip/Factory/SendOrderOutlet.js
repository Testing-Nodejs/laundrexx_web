/* eslint-disable no-restricted-globals */
/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState } from "react";
import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCol,
    CDataTable,
    CForm,
    CFormGroup,
    CInput,
    CLabel,
    CTextarea,
    CRow,
    CLink,
} from "@coreui/react";
import EditIcon from "@material-ui/icons/Edit";
import DeleteSharpIcon from "@material-ui/icons/DeleteSharp";
import axios from "axios";
import { MyApiUrl } from "src/services/service";
import Swal from "sweetalert2";
import "../../style.css";
import { useHistory } from "react-router-dom";

const SendOrders = () => {
    const history = useHistory();

    const FactoryID = sessionStorage.getItem("FactoryID");
    const StaffID = sessionStorage.getItem("UserID");

    const [OrderNo, setOrderNo] = useState("");
    const [OrderDet, setOrderDet] = useState([]);
    const [OutletId, setOutletId] = useState("");
    const [TotalQty, setTotalQty] = useState(0);

    const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 1500,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener("mouseenter", Swal.stopTimer);
            toast.addEventListener("mouseleave", Swal.resumeTimer);
        },
    });

    const GetOrderItemDetails = (num) => {
        const obj = {
            OrderNumber: num,
        }
        axios.post(MyApiUrl + "OrderDetailsByNumber", obj).then((response) => {
            console.log(response);
            if (response.data.length > 0) {

                if (OutletId === "") {
                    setTotalQty(TotalQty + response.data[0].TotalQuantity);

                    setOutletId(response.data[0].ORDER_OUTLET_FKID);

                    const obj = {
                        OrderNumber: response.data[0].ORDER_ORDER_NUMBER,
                        Quantity: response.data[0].TotalQuantity,
                        TotalBags: "1",
                        DueDate: SplitDate1(response.data[0].ORDER_DUE_DATE),
                        Pkid: response.data[0].ORDER_PKID,
                        CustomerName: response.data[0].CUSTOMER_NAME
                    }
                    if (OrderDet.length > 0) {
                        const existingOrder = OrderDet.findIndex(item => item.Pkid === response.data[0].ORDER_PKID);
                        if (existingOrder === "-1" || existingOrder === -1) {
                            setOrderDet([...OrderDet, obj]);
                            setOrderNo("");
                            document.getElementById("NumOrder").focus();
                        } else {
                            Swal.fire({
                                title: "Order Already Exist!",
                                text: "If you want to edit order please delete and add new order.",
                                icon: "error",
                                confirmButtonText: "OK",
                            });
                            setOrderNo("");
                            document.getElementById("NumOrder").focus();
                        }
                    } else {
                        setOrderDet([...OrderDet, obj]);
                        setOrderNo("");
                        document.getElementById("NumOrder").focus();

                    }


                } else {

                    if (OutletId === response.data[0].ORDER_OUTLET_FKID) {
                        setTotalQty(TotalQty + response.data[0].TotalQuantity);
                        const obj = {
                            OrderNumber: response.data[0].ORDER_ORDER_NUMBER,
                            Quantity: response.data[0].TotalQuantity,
                            TotalBags: "1",
                            DueDate: SplitDate1(response.data[0].ORDER_DUE_DATE),
                            Pkid: response.data[0].ORDER_PKID,
                            CustomerName: response.data[0].CUSTOMER_NAME
                        }
                        if (OrderDet.length > 0) {
                            const existingOrder = OrderDet.findIndex(item => item.Pkid === response.data[0].ORDER_PKID);
                            if (existingOrder === "-1" || existingOrder === -1) {
                                setOrderDet([...OrderDet, obj]);
                                setOrderNo("");
                                document.getElementById("NumOrder").focus();
                            } else {
                                Swal.fire({
                                    title: "Order Already Exist!",
                                    text: "If you want to edit order please delete and add new order.",
                                    icon: "error",
                                    confirmButtonText: "OK",
                                });
                                setOrderNo("");
                                document.getElementById("NumOrder").focus();
                            }
                        } else {
                            setOrderDet([...OrderDet, obj]);
                            setOrderNo("");
                            document.getElementById("NumOrder").focus();

                        }

                    } else {
                        Swal.fire({
                            title: "Please Enter /Scan " + response.data[0].STORE_NAME + " Order Numbers",
                            icon: "error",
                            confirmButtonText: "OK",
                        });
                        setOrderNo("");
                        document.getElementById("NumOrder").focus();
                    }

                }
            }
        });
    }

    const UpdateTotalBags = (event) => {
        const updatedData = OrderDet.map((item) => {
            if (parseInt(item.Pkid) === parseInt(event.target.id)) {
                return { ...item, TotalBags: event.target.value };
            }
            return item;
        });
        setOrderDet(updatedData);
    }

    const SplitDate1 = (OrderDate) => {
        const MainDate = OrderDate.split("T");
        const SplitT = MainDate[0];
        const OrderDates = SplitT.split("-");
        const FinalDate = OrderDates[2] + "-" + OrderDates[1] + "-" + OrderDates[0];
        return FinalDate;
    }

    const SubmitFinalItemDetails = () => {
        var obj = {
            DCNumber: "",
            FactoryID: FactoryID,
            OutletID: OutletId,
            StaffID: StaffID,
            OrdersList: OrderDet,
            TotalQuantity: TotalQty,
            TotalBags: "1",
        }
        console.log(obj)
        document.getElementById("divLoading").className = "show";
        axios.post(MyApiUrl + "ReturnToOutlet", obj).then((response) => {
            console.log(response.data);
            if (response.data === true) {
                Swal.fire({
                    title: "Outlet Details Submitted!",
                    icon: "success",
                    confirmButtonText: "OK",
                });
                document.getElementById("divLoading").className = "hide";
                Reload();
                history.push("/SentOutletDCDetails");
            } else if (response.data === false) {
                Swal.fire({
                    title: "Failed To Submit!",
                    icon: "error",
                    confirmButtonText: "OK",
                });
                document.getElementById("divLoading").className = "hide";
            }
        });

    }

    const DeleteOrderItem = (pkid) => {
        let newArr = OrderDet.filter((x) => x.Pkid !== pkid);
        setOrderDet(newArr);
        let TotalQty = 0;
        for (let i = 0; i < newArr.length; i++) {
            TotalQty = TotalQty + newArr[i].Quantity;
        }
        setTotalQty(TotalQty);
    }
    
    const DeleteAllOrderItem = () => {
        setOrderDet([]);
        setTotalQty(0);
    }

    const Reload = () => {
        setOrderNo("");
        setOrderDet([]);
        setTotalQty(0);
    }

    React.useEffect(() => {
        document.getElementById("NumOrder").focus();
        Reload();
    }, []);
    return (
        <div className="123">
            <div id="divLoading"> </div>
            <h1 id="ccmaster">Send/Return to outlet</h1>
            <CRow>
                <CCol md="12" lg="1"></CCol>
                <CCol md="12" lg="11">
                    <CLink to="/SendOrder">
                        <CButton size="sm" className="btn btn-danger" style={{ marginBottom: 0, marginTop: 0, float: "left", width: "7%" }}>
                            Back
                        </CButton>
                    </CLink>
                </CCol>
            </CRow>
            <CRow style={{ marginTop: "3%", alignContent: "center" }}>
                <CCol md="12" lg="3"></CCol>
                <CCol md="12" lg="6">
                    <CCard style={{ boxShadow: "0px 0px 1px 1px #959595" }}>
                        <CCardHeader>Add Order No to DC</CCardHeader>
                        <CCardBody>
                            <CFormGroup row>
                                <CCol xs="12" md="12">
                                    <CLabel>Order No<span style={{ color: "red" }}> *</span></CLabel>
                                    <CInput
                                        id="NumOrder"
                                        name="NumOrder"
                                        placeholder="Enter Order No / Scan QR Code"
                                        value={OrderNo}
                                        onChange={(event) => {
                                            setOrderNo(event.target.value);
                                            GetOrderItemDetails(event.target.value);
                                        }}
                                    />
                                </CCol>
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol md="12" lg="3"></CCol>
                {OrderDet.length > 0
                    ?
                    <CCol md="12" lg="12">

                        <CCard style={{ boxShadow: "0px 0px 1px 1px #959595" }}>
                            <CCardHeader>
                                <div style={{ float: "left" }}>
                                    View Added Orders in DC
                                </div>
                                <div style={{ float: "right" }}>
                                    <CButton
                                        size="sm"
                                        className="btn btn-success"
                                        onClick={DeleteAllOrderItem}
                                    >
                                        Delete
                                    </CButton>
                                </div>
                            </CCardHeader>
                            <div style={{ overflow: "auto" }}>

                                <table
                                    className="table table-responsive-sm table-bordered table-hover"
                                    id="OutletPlaceOrderCouponTable"
                                >
                                    <thead>
                                        {/* <th colSpan={4}>DC No: {DCNo}</th>
                                                <th colSpan={2}>Date:{CurrentDate}</th> */}
                                        <tr>
                                            <th>
                                                <strong>Sl No</strong>
                                            </th>
                                            <th>
                                                <strong>Order No</strong>
                                            </th>
                                            <th>
                                                <strong>Customer Name</strong>
                                            </th>
                                            <th>
                                                <strong>Due Date</strong>
                                            </th>
                                            <th>
                                                <strong>Quantity</strong>
                                            </th>
                                            <th>
                                                <strong>Total Bags</strong>
                                            </th>
                                            <th><strong>Action</strong></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {OrderDet.map((item, index) => (
                                            <tr>
                                                <td>{index + 1}</td>
                                                <td>{item.OrderNumber}</td>
                                                <td>{item.CustomerName}</td>
                                                <td>{item.DueDate}</td>
                                                <td>{item.Quantity}</td>
                                                <td style={{ width: "20%" }}><CInput type="number"
                                                    id={item.Pkid}
                                                    value={item.TotalBags}
                                                    onChange={UpdateTotalBags}
                                                /></td>
                                                <td><CButton
                                                    size="sm"
                                                    onClick={() => {
                                                        DeleteOrderItem(item.Pkid);
                                                    }}
                                                    id="war-btn1"
                                                >
                                                    <DeleteSharpIcon />
                                                </CButton></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>

                            </div>

                        </CCard>
                        <CRow>
                            <CCol lg="12" md="12">
                                <CButton
                                    size="md"
                                    id="btn1"
                                    style={{
                                        backgroundColor: "green",
                                        size: 20,
                                        color: "white",
                                        float: "right"
                                    }}
                                    onClick={SubmitFinalItemDetails}
                                >
                                    Submit
                                </CButton>
                            </CCol>
                        </CRow>
                    </CCol> : null}
            </CRow>
        </div>
    );
};

export default SendOrders;